source for blob detection web-app: http://tangiblejs.com/posts/tracking-color-blobs-in-webcam-feed-using-tracking-js
source for synthesizer js library: https://tonejs.github.io/
